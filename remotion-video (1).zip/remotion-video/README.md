# AI দিয়ে ভিডিও এডিটিং — Remotion প্রজেক্ট

- Composition ID: `Main` · Entry: `src/index.ts` · 1920×1080 · 30fps
- সময় ও কনটেন্ট: `public/subtitles.srt` (বদলালে `node scripts/gen-srt-module.mjs`)
- রং/ফন্ট/easing: `src/theme.ts` · ভয়েসওভার flag: `src/config.ts`
- SFX: `public/sfx/*.wav` (পুনরায় তৈরি: `npm run sfx`)

```
npm install
npx remotion studio
npx remotion render src/index.ts Main out/video.mp4
```
