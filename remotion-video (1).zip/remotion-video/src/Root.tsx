import React from "react";
import { Composition } from "remotion";
import { Main } from "./Main";
import { TOTAL_FRAMES } from "./srt";
import { theme } from "./theme";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Main"
      component={Main}
      // সময়কাল SRT-র শেষ cue থেকে
      durationInFrames={TOTAL_FRAMES(theme.video.fps)}
      fps={theme.video.fps}
      width={theme.video.width}
      height={theme.video.height}
    />
  );
};
