import React from "react";
import { Audio, Sequence, staticFile, useVideoConfig } from "remotion";
import type { SceneTiming } from "../timeline";

export type SfxName = "pop" | "click" | "whoosh" | "chime" | "thud";

export type SfxCue = { frame: number; name: SfxName; volume?: number; rate?: number };

// ফাইল গেইন সমান (peak ≈ 0.9); এখানে চূড়ান্ত ভলিউম ০.২–০.৩৫-এর মধ্যে
const BASE_VOLUME: Record<SfxName, number> = {
  pop: 0.3,
  click: 0.35,
  whoosh: 0.24,
  chime: 0.26,
  thud: 0.3,
};

export const Sfx: React.FC<{ cues: SfxCue[] }> = ({ cues }) => {
  const { fps } = useVideoConfig();
  return (
    <>
      {cues.map((c, i) => (
        <Sequence key={i} from={Math.max(0, Math.round(c.frame))} durationInFrames={fps} layout="none">
          <Audio
            src={staticFile(`sfx/${c.name}.wav`)}
            volume={c.volume ?? BASE_VOLUME[c.name]}
            playbackRate={c.rate ?? 1}
          />
        </Sequence>
      ))}
    </>
  );
};

// ভিজ্যুয়াল ল্যান্ড করার ~৩ frame আগে sound শুরু (early = synced অনুভূতি)
const PRE = 3;

/** প্রতিটি দৃশ্যের local frame → global frame; প্রধান entry/reveal/transition-এ SFX */
export const buildSfxCues = (tl: SceneTiming[]): SfxCue[] => {
  const g = (i: number, local: number) => tl[i].from + local - PRE;
  const cues: SfxCue[] = [];

  // হুক
  cues.push({ frame: 0, name: "thud", volume: 0.26 });
  cues.push({ frame: g(0, 9), name: "pop" });
  cues.push({ frame: g(0, tl[0].at(1, 0.5, 14)), name: "click", volume: 0.22 });

  // দৃশ্য transition: নরম whoosh (সামান্য pitch variation)
  const rates = [1, 0.96, 1.04, 0.98, 1.02, 0.95, 1.03, 0.97, 1.01, 0.99, 1.04];
  for (let i = 1; i < tl.length; i++) {
    cues.push({ frame: tl[i].from - 2, name: "whoosh", rate: rates[(i - 1) % rates.length] });
  }

  cues.push({ frame: g(1, 20), name: "pop" }); // S2: window reveal
  cues.push({ frame: g(2, 8), name: "pop", rate: 1.04 }); // S3: প্রথম কার্ড
  cues.push({ frame: g(3, 4), name: "pop", rate: 0.92 }); // S4: hub
  cues.push({ frame: g(4, 12), name: "pop", rate: 1.02 }); // S5: window
  cues.push({ frame: g(5, tl[5].at(6, 0, 26) + 5), name: "click", volume: 0.24 }); // S6: highlight sweep
  cues.push({ frame: g(6, 6), name: "pop", rate: 0.98 }); // S7: প্রথম node
  cues.push({ frame: g(6, tl[6].at(7, 2 / 3, -5) + 10), name: "click" }); // S7: শেষ checkmark
  cues.push({ frame: g(7, 6 * 2 + 4 + tl[7].at(8, 0, -5)), name: "pop", rate: 0.9 }); // S8: "কেন?"
  cues.push({ frame: g(8, tl[8].at(9, 0, -5) + 52), name: "chime" }); // S9: গন্তব্য reveal
  cues.push({ frame: g(9, 14), name: "pop", rate: 1.03 }); // S10: card reveal
  cues.push({ frame: g(9, tl[9].at(11, 0, 14)), name: "click", volume: 0.3 }); // S10: follow ক্লিক
  cues.push({ frame: g(10, tl[10].at(13, 0, 0) * 0 + tl[10].at(12, 0, 34) + 5), name: "click", volume: 0.24 }); // S11: highlight
  cues.push({ frame: g(11, tl[11].at(13, 0.36, 0) - 6 + 4), name: "chime", volume: 0.3 }); // S12: "আজই!"
  cues.push({ frame: g(11, tl[11].at(13, 0.36, 18)), name: "pop", rate: 1.06, volume: 0.22 }); // S12: recap

  return cues;
};
