import React from "react";
import { Audio, getRemotionEnvironment, getStaticFiles, staticFile } from "remotion";
import { VOICEOVER_IN_RENDER, VOICEOVER_PREVIEW } from "../config";

const FILE = "voiceover.mp3";

// public/voiceover.mp3 থাকলে Studio preview-তে চালায়; না থাকলে কিছুই render করে না।
// render-এর সময় ডিফল্টে বন্ধ (config.ts-এ VOICEOVER_IN_RENDER = true করলে চালু)।
export const PreviewAudio: React.FC = () => {
  if (!VOICEOVER_PREVIEW) return null;
  const { isRendering } = getRemotionEnvironment();
  if (isRendering && !VOICEOVER_IN_RENDER) return null;

  if (!isRendering) {
    let exists = false;
    try {
      exists = getStaticFiles().some((f) => f.name === FILE);
    } catch {
      exists = false;
    }
    if (!exists) return null;
  }
  return <Audio src={staticFile(FILE)} />;
};
