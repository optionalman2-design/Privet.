// SRT cue → দৃশ্য। সব timing এখান থেকেই হিসাব হয় (fps থেকে frame)।
import { CUES, getCue, msToFrame } from "./srt";

// বক্তব্যের ~৫ frame আগে ভিজ্যুয়াল ঢোকে
export const LEAD = 5;
export const EARLY = -LEAD;

export type SceneDef = { id: string; cues: number[] };

export const SCENE_DEFS: SceneDef[] = [
  { id: "hook", cues: [1] },
  { id: "ai-look", cues: [2] },
  { id: "four-things", cues: [3] },
  { id: "hub", cues: [4] },
  { id: "capcut", cues: [5] },
  { id: "statement", cues: [6] },
  { id: "steps", cues: [7] },
  { id: "no-delay", cues: [8] },
  { id: "journey", cues: [9] },
  { id: "follow", cues: [10, 11] },
  { id: "practice", cues: [12] },
  { id: "finale", cues: [13] },
];

export type SceneTiming = {
  id: string;
  from: number; // composition frame যেখানে Sequence শুরু
  duration: number;
  /** cue শুরুর local frame (Sequence-এর ভেতরে) */
  cueStart: (cueId: number) => number;
  cueDur: (cueId: number) => number;
  /** cue-র ভেতরে frac (0..1) অবস্থানের local frame + offset */
  at: (cueId: number, frac?: number, offset?: number) => number;
};

export const buildTimeline = (fps: number): SceneTiming[] =>
  SCENE_DEFS.map((def, i) => {
    const first = getCue(def.cues[0]);
    const last = getCue(def.cues[def.cues.length - 1]);
    const lead = i === 0 ? 0 : LEAD;
    const from = Math.max(0, msToFrame(first.startMs, fps) - lead);
    const end = msToFrame(last.endMs, fps);
    const cueStart = (id: number) => msToFrame(getCue(id).startMs, fps) - from;
    const cueDur = (id: number) => {
      const c = getCue(id);
      return msToFrame(c.endMs, fps) - msToFrame(c.startMs, fps);
    };
    return {
      id: def.id,
      from,
      duration: end - from,
      cueStart,
      cueDur,
      at: (id, frac = 0, offset = 0) => Math.round(cueStart(id) + cueDur(id) * frac + offset),
    };
  });

export const ALL_CUE_COUNT = CUES.length;
