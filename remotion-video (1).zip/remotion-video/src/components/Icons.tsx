import React from "react";
import { theme } from "../theme";

export type IconName = "cut" | "transition" | "subtitle" | "music" | "spark" | "check" | "play" | "arrow";

type IconProps = {
  name: IconName;
  size?: number;
  color?: string;
  stroke?: number;
  /** check আইকনের আঁকা অগ্রগতি (0..1) */
  draw?: number;
  style?: React.CSSProperties;
};

// সব আইকন CSS/SVG-তে আঁকা (emoji নয়), theme রঙে
export const Icon: React.FC<IconProps> = ({
  name,
  size = 64,
  color = theme.colors.text,
  stroke = 3.2,
  draw = 1,
  style,
}) => {
  const common = {
    fill: "none",
    stroke: color,
    strokeWidth: stroke,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  let body: React.ReactNode = null;
  switch (name) {
    case "cut":
      body = (
        <g {...common}>
          <circle cx="13" cy="36" r="6" />
          <circle cx="35" cy="36" r="6" />
          <path d="M17.5 31.5 L37 8 M30.5 31.5 L11 8" />
        </g>
      );
      break;
    case "transition":
      body = (
        <g {...common}>
          <rect x="4" y="11" width="24" height="26" rx="6" />
          <rect x="20" y="11" width="24" height="26" rx="6" />
          <path d="M17 24 H31 M26 19 L31 24 L26 29" />
        </g>
      );
      break;
    case "subtitle":
      body = (
        <g {...common}>
          <rect x="4" y="9" width="40" height="30" rx="7" />
          <path d="M12 23 H21 M26 23 H36 M12 31 H27 M32 31 H36" />
        </g>
      );
      break;
    case "music":
      body = (
        <g {...common}>
          <path d="M18 35 V10 L39 6 V31" />
          <circle cx="12" cy="35" r="6" />
          <circle cx="33" cy="31" r="6" />
        </g>
      );
      break;
    case "spark":
      body = (
        <path
          d="M24 3 L29 19 L45 24 L29 29 L24 45 L19 29 L3 24 L19 19 Z"
          fill={color}
          stroke={color}
          strokeWidth={2}
          strokeLinejoin="round"
        />
      );
      break;
    case "check":
      body = (
        <path
          d="M10 25 L20 35 L38 14"
          {...common}
          strokeWidth={stroke + 1.4}
          strokeDasharray={40}
          strokeDashoffset={40 * (1 - draw)}
        />
      );
      break;
    case "play":
      body = <path d="M15 8 L40 24 L15 40 Z" fill={color} stroke={color} strokeWidth={4} strokeLinejoin="round" />;
      break;
    case "arrow":
      body = <path d="M8 24 H38 M28 14 L38 24 L28 34" {...common} />;
      break;
  }
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" style={{ display: "block", ...style }}>
      {body}
    </svg>
  );
};
