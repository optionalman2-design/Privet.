import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { alpha, theme } from "../theme";

// ১ম স্তর: সচল mesh ব্যাকগ্রাউন্ড (কখনো flat নয়)
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 70;
  const d2 = Math.cos(frame / 70) * 55;
  const mask = "radial-gradient(ellipse at center, black 15%, transparent 75%)";
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div
        style={{
          position: "absolute",
          width: 1400,
          height: 1400,
          borderRadius: "50%",
          top: -620,
          left: -380 + d1,
          background: `radial-gradient(circle, ${alpha(theme.colors.hero, 0.3)}, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1100,
          height: 1100,
          borderRadius: "50%",
          bottom: -560,
          right: -300 - d2,
          background: `radial-gradient(circle, ${alpha(theme.colors.accent, 0.2)}, transparent 65%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: `radial-gradient(${alpha(theme.colors.text, 0.13)} 1.6px, transparent 1.8px)`,
          backgroundSize: "60px 60px",
          backgroundPosition: `${frame * 0.2}px ${frame * 0.12}px`,
          maskImage: mask,
          WebkitMaskImage: mask,
        }}
      />
    </AbsoluteFill>
  );
};

// ৪র্থ স্তর: color grade
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill
      style={{ backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.2 }}
    />
    <AbsoluteFill
      style={{
        background: `linear-gradient(180deg, ${alpha(theme.colors.black, 0.12)}, transparent 28%, transparent 72%, ${alpha(theme.colors.black, 0.22)})`,
      }}
    />
  </AbsoluteFill>
);

// ৫ম স্তর: grain + vignette
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: `radial-gradient(ellipse at center, transparent 56%, ${alpha(theme.colors.black, 0.32)} 100%)`,
    }}
  />
);
