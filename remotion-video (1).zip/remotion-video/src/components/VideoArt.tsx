import React from "react";
import { alpha, theme } from "../theme";

// ভিডিও ফ্রেমের মক ছবি (পুরোটাই SVG, কোনো বাইরের asset নয়)
export const VideoArt: React.FC<{ width: number; height: number; id: string }> = ({
  width,
  height,
  id,
}) => (
  <svg
    width={width}
    height={height}
    viewBox="0 0 800 450"
    preserveAspectRatio="xMidYMid slice"
    style={{ display: "block" }}
  >
    <defs>
      <linearGradient id={`${id}-sky`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={theme.colors.hero} />
        <stop offset="0.7" stopColor={theme.colors.surface} />
        <stop offset="1" stopColor={theme.colors.bgAlt} />
      </linearGradient>
      <radialGradient id={`${id}-sun`} cx="0.5" cy="0.5" r="0.5">
        <stop offset="0" stopColor={theme.colors.accent} />
        <stop offset="1" stopColor={alpha(theme.colors.accent, 0)} />
      </radialGradient>
    </defs>
    <rect width="800" height="450" fill={`url(#${id}-sky)`} />
    <circle cx="590" cy="150" r="120" fill={`url(#${id}-sun)`} opacity="0.55" />
    <circle cx="590" cy="150" r="58" fill={theme.colors.accent} />
    <path d="M0 450 V300 L150 190 L290 300 L420 215 L620 370 L800 270 V450 Z" fill={theme.colors.surface} />
    <path d="M0 450 V350 L190 270 L360 380 L520 300 L800 400 V450 Z" fill={theme.colors.bg} opacity="0.92" />
  </svg>
);
