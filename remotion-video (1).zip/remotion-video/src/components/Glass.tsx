import React from "react";
import { alpha, theme } from "../theme";

type GlassProps = React.PropsWithChildren<{
  width?: number | string;
  height?: number | string;
  radius?: number;
  /** 0..1 — সক্রিয় কার্ডে hero border + glow */
  active?: number;
  style?: React.CSSProperties;
}>;

export const GlassCard: React.FC<GlassProps> = ({
  width,
  height,
  radius = theme.radius.card,
  active = 0,
  style,
  children,
}) => (
  <div
    style={{
      position: "relative",
      width,
      height,
      borderRadius: radius,
      overflow: "hidden",
      background: `linear-gradient(155deg, ${theme.colors.glassHi}, ${theme.colors.glassLo})`,
      border: `2px solid ${active > 0 ? alpha(theme.colors.hero, 0.3 + 0.6 * active) : theme.colors.glassBorder}`,
      boxShadow: `0 44px 80px -28px ${theme.colors.shadow}, 0 0 ${70 * active}px ${alpha(theme.colors.hero, 0.45 * active)}`,
      ...style,
    }}
  >
    <div
      style={{
        position: "absolute",
        inset: 0,
        pointerEvents: "none",
        background: `linear-gradient(180deg, ${alpha(theme.colors.white, 0.1)}, transparent 34%)`,
      }}
    />
    {children}
  </div>
);

export const Chip: React.FC<
  React.PropsWithChildren<{ size?: number; color?: string; style?: React.CSSProperties }>
> = ({ size = 44, color = theme.colors.accent, style, children }) => (
  <div
    style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 14,
      padding: `${Math.round(size * 0.2)}px ${Math.round(size * 0.55)}px`,
      borderRadius: theme.radius.pill,
      border: `2px solid ${alpha(color, 0.55)}`,
      background: alpha(color, 0.12),
      color,
      fontFamily: theme.fonts.body,
      fontSize: size,
      fontWeight: 600,
      lineHeight: 1.35,
      letterSpacing: 0,
      whiteSpace: "nowrap",
      ...style,
    }}
  >
    {children}
  </div>
);
