import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { alpha, theme } from "../theme";

export const CLAMP = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

export type SpringCfg = { damping: number; stiffness: number; mass: number };

/** delay-সহ spring (পূর্ণ pure function — loop-এর ভেতরেও নিরাপদ) */
export const sp = (
  frame: number,
  fps: number,
  delay = 0,
  config: SpringCfg = theme.spring.smooth,
): number => spring({ frame: Math.max(0, frame - delay), fps, config });

/** bezier ease-out দিয়ে 0→1 */
export const ramp = (frame: number, start: number, dur = 14, easing = theme.ease.out): number =>
  interpolate(frame, [start, start + dur], [0, 1], { easing, ...CLAMP });

const clamp01 = (n: number) => Math.min(1, Math.max(0, n));

// ─── প্রবেশ: opacity + translateY + scale ───
type EntranceProps = React.PropsWithChildren<{
  delay?: number;
  y?: number;
  from?: number;
  config?: SpringCfg;
  style?: React.CSSProperties;
}>;

export const Entrance: React.FC<EntranceProps> = ({
  delay = 0,
  y = 40,
  from = 0.94,
  config = theme.spring.smooth,
  style,
  children,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = sp(frame, fps, delay, config);
  return (
    <div
      style={{
        opacity: clamp01(p),
        transform: `translateY(${(1 - p) * y}px) scale(${from + (1 - from) * p})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

// ─── দৃশ্য wrapper: দ্রুত exit (~১০ frame) ───
export const SceneShell: React.FC<
  React.PropsWithChildren<{ duration: number; exit?: boolean }>
> = ({ duration, exit = true, children }) => {
  const frame = useCurrentFrame();
  const x = exit
    ? interpolate(frame, [duration - 10, duration - 1], [0, 1], { easing: theme.ease.in, ...CLAMP })
    : 0;
  return (
    <AbsoluteFill
      style={{
        opacity: 1 - x,
        transform: `translateY(${-30 * x}px) scale(${1 - 0.02 * x})`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

// ─── Word-by-word stagger (শব্দ ভাগ শুধু space-এ; letterSpacing 0) ───
export type WordEmphasis = { color?: string; glow?: boolean; pop?: boolean };

type WordsProps = {
  text: string;
  size: number;
  delay?: number;
  per?: number;
  color?: string;
  weight?: 400 | 500 | 600 | 700;
  align?: "left" | "center";
  maxWidth?: number;
  gap?: number;
  lineHeight?: number;
  emphasis?: Record<number, WordEmphasis>;
  style?: React.CSSProperties;
};

export const Words: React.FC<WordsProps> = ({
  text,
  size,
  delay = 0,
  per = 4,
  color = theme.colors.text,
  weight = 700,
  align = "center",
  maxWidth,
  gap,
  lineHeight = 1.32,
  emphasis = {},
  style,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const colGap = gap ?? Math.round(size * 0.26); // px, em নয়
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align === "center" ? "center" : "flex-start",
        columnGap: colGap,
        rowGap: 0,
        maxWidth,
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {text.split(" ").map((word, i) => {
        const e = emphasis[i];
        const p = sp(frame, fps, delay + i * per, e?.pop ? theme.spring.bouncy : theme.spring.snappy);
        const s = e?.pop ? 0.55 + 0.45 * p : 1;
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              whiteSpace: "nowrap",
              opacity: clamp01(p * 1.4),
              transform: `translateY(${(1 - p) * 34}px) scale(${s})`,
              color: e?.color ?? color,
              textShadow: e?.glow
                ? `0 0 40px ${theme.colors.glow}, 0 0 90px ${alpha(theme.colors.hero, 0.3)}`
                : undefined,
            }}
          >
            {word}
          </span>
        );
      })}
    </div>
  );
};

// ─── line-mask reveal (পুরো লাইন নিচ থেকে উঠে আসে; glyph-wise নয়) ───
export const LineMask: React.FC<React.PropsWithChildren<{ delay?: number; pad?: number; padX?: number }>> = ({
  delay = 0,
  pad = 26,
  padX = 44,
  children,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = sp(frame, fps, delay, theme.spring.smooth);
  return (
    <div style={{ overflow: "hidden", padding: `${pad}px ${padX}px`, margin: `${-pad}px ${-padX}px` }}>
      <div style={{ transform: `translateY(${(1 - p) * 115}%)`, opacity: clamp01(p * 2) }}>
        {children}
      </div>
    </div>
  );
};

// ─── highlight sweep: বাঁ থেকে ডানে ভরাট হওয়া bar (টেক্সটের পেছনে) ───
export const HighlightBar: React.FC<{ delay: number; color?: string; dur?: number }> = ({
  delay,
  color = theme.colors.hero,
  dur = 16,
}) => {
  const frame = useCurrentFrame();
  const p = ramp(frame, delay, dur);
  return (
    <div
      style={{
        position: "absolute",
        left: -22,
        right: -22,
        top: "14%",
        bottom: "4%",
        borderRadius: 22,
        background: color,
        transformOrigin: "left center",
        transform: `scaleX(${p})`,
        boxShadow: `0 0 70px ${alpha(color, 0.45)}`,
      }}
    />
  );
};

/** চলমান idle micro-motion (>২ সেকেন্ড স্ক্রিনে থাকা উপাদানের জন্য) */
export const useFloat = (seed = 0, amp = 4): number => {
  const frame = useCurrentFrame();
  return Math.sin(frame / 30 + seed) * amp;
};
