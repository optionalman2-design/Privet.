import type { SceneTiming } from "../timeline";

export type SceneProps = { t: SceneTiming };
