import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { CLAMP, Entrance, SceneShell, Words, useFloat } from "../components/Motion";
import { Chip, GlassCard } from "../components/Glass";
import { Icon } from "../components/Icons";
import { VideoArt } from "../components/VideoArt";
import { alpha, theme } from "../theme";
import { EARLY } from "../timeline";
import type { SceneProps } from "./types";

const W = 1120;
const HEADER = 48;
const PREVIEW = 330;
const TIMELINE = 142;

// টাইমলাইনের ক্লিপ (শতাংশে)
const CLIPS = [
  { row: 0, x: 3, w: 30 },
  { row: 0, x: 36, w: 22 },
  { row: 0, x: 61, w: 34 },
  { row: 1, x: 10, w: 26 },
  { row: 1, x: 40, w: 38 },
  { row: 2, x: 3, w: 44 },
  { row: 2, x: 52, w: 25 },
];

// cue 2: "এখন AI-এর যুগে আপনি খুব সহজেই নিজের ভিডিওকে প্রফেশনাল লুকে রূপ দিতে পারবেন।"
export const S02AiLook: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const s = t.at(2, 0, EARLY);
  const sweepStart = t.at(2, 0.12, 0);
  const sweepEnd = t.at(2, 0.82, 0);
  const pct = interpolate(frame, [sweepStart, sweepEnd], [4, 100], { easing: theme.ease.inOut, ...CLAMP });
  const handleO = interpolate(pct, [94, 100], [1, 0], CLAMP);
  const floatY = useFloat(1, 3);

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 22 }}>
          <Entrance delay={s}>
            <Chip size={44}>
              <Icon name="spark" size={34} color={theme.colors.accent} />
              AI-এর যুগে
            </Chip>
          </Entrance>
          <Words text="প্রফেশনাল লুক" size={128} delay={s + 6} per={5} />
          <Entrance delay={s + 14} y={60}>
            <div style={{ transform: `translateY(${floatY}px)` }}>
              <GlassCard width={W} height={HEADER + PREVIEW + TIMELINE} radius={34}>
                {/* header */}
                <div
                  style={{
                    height: HEADER,
                    display: "flex",
                    alignItems: "center",
                    gap: 12,
                    padding: "0 22px",
                    borderBottom: `1px solid ${theme.colors.hairline}`,
                  }}
                >
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      style={{ width: 14, height: 14, borderRadius: 7, background: alpha(theme.colors.white, 0.28) }}
                    />
                  ))}
                </div>
                {/* preview: before / after slider */}
                <div style={{ position: "relative", width: W, height: PREVIEW, overflow: "hidden" }}>
                  <div style={{ filter: "grayscale(1) contrast(0.7) brightness(0.62)" }}>
                    <VideoArt width={W} height={PREVIEW} id="s2b" />
                  </div>
                  <div style={{ position: "absolute", inset: 0, clipPath: `inset(0 ${100 - pct}% 0 0)` }}>
                    <VideoArt width={W} height={PREVIEW} id="s2a" />
                  </div>
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      bottom: 0,
                      left: `${pct}%`,
                      width: 5,
                      marginLeft: -2,
                      background: theme.colors.hero,
                      boxShadow: `0 0 36px ${theme.colors.glow}`,
                      opacity: handleO,
                    }}
                  >
                    <div
                      style={{
                        position: "absolute",
                        top: "50%",
                        left: "50%",
                        width: 64,
                        height: 64,
                        marginLeft: -32,
                        marginTop: -32,
                        borderRadius: 32,
                        background: theme.colors.hero,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        boxShadow: `0 0 50px ${theme.colors.glow}`,
                      }}
                    >
                      <Icon name="spark" size={34} color={theme.colors.white} />
                    </div>
                  </div>
                </div>
                {/* timeline */}
                <div style={{ position: "relative", height: TIMELINE, padding: "18px 24px" }}>
                  {CLIPS.map((c, i) => {
                    const passed = interpolate(pct, [c.x, c.x + 6], [0, 1], CLAMP);
                    return (
                      <div
                        key={i}
                        style={{
                          position: "absolute",
                          top: 18 + c.row * 38,
                          left: `calc(${c.x}% + 0px)`,
                          width: `${c.w * 0.97}%`,
                          height: 28,
                          borderRadius: 9,
                          background: passed > 0.5 ? alpha(theme.colors.accent, 0.55) : alpha(theme.colors.white, 0.14),
                          border: `1px solid ${alpha(theme.colors.white, 0.18)}`,
                        }}
                      />
                    );
                  })}
                  <div
                    style={{
                      position: "absolute",
                      top: 8,
                      bottom: 8,
                      left: `${pct}%`,
                      width: 3,
                      background: theme.colors.text,
                      opacity: handleO,
                    }}
                  />
                </div>
              </GlassCard>
            </div>
          </Entrance>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
