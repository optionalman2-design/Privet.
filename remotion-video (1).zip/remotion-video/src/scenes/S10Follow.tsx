import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { CLAMP, Entrance, SceneShell, Words, ramp, sp, useFloat } from "../components/Motion";
import { GlassCard } from "../components/Glass";
import { Icon } from "../components/Icons";
import { alpha, theme } from "../theme";
import { EARLY } from "../timeline";
import type { SceneProps } from "./types";

const CARD_W = 700;
const CARD_H = 580;
const BTN = { left: 44, right: 44, bottom: 44, h: 100 };

// cue 10: "আর AI দিয়ে ভিডিও তৈরি ও এডিটিং শিখতে চাইলে"  |  cue 11: "পেজটি ফলো করুন।"
export const S10Follow: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = t.at(10, 0, EARLY);
  const press = t.at(11, 0, 14); // বাটনে ক্লিক
  const floatY = useFloat(3, 3);

  // cursor (card-এর স্থানাঙ্কে)
  const tipEnd = { x: CARD_W / 2 + 190, y: CARD_H - BTN.bottom - BTN.h / 2 + 8 };
  const tipStart = { x: CARD_W - 40, y: CARD_H - 10 };
  const cp = interpolate(frame, [t.at(11, 0, -26), press - 2], [0, 1], { easing: theme.ease.inOut, ...CLAMP });
  const cx = tipStart.x + (tipEnd.x - tipStart.x) * cp;
  const cy = tipStart.y + (tipEnd.y - tipStart.y) * cp;
  const cursorO = interpolate(frame, [t.at(11, 0, -26), t.at(11, 0, -18)], [0, 1], CLAMP);

  const pressDip = interpolate(frame, [press, press + 3, press + 9], [1, 0.94, 1], CLAMP);
  const ripple = ramp(frame, press, 22);
  const done = sp(frame, fps, press + 3, theme.spring.bouncy);

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 120, top: 0, bottom: 0, width: 900, display: "flex", flexDirection: "column", justifyContent: "center", gap: 10 }}>
          <Words
            text="AI দিয়ে ভিডিও"
            size={104}
            align="left"
            delay={s}
            per={4}
            emphasis={{ 0: { color: theme.colors.accent } }}
          />
          <Words text="তৈরি ও এডিটিং" size={104} align="left" delay={s + 12} per={4} />
          <Words text="শিখতে চাইলে" size={62} weight={500} align="left" color={theme.colors.textDim} delay={s + 28} per={4} />
        </div>

        <div style={{ position: "absolute", right: 130, top: (1080 - CARD_H) / 2 }}>
          <Entrance delay={s + 8} y={60} from={0.92}>
            <div style={{ transform: `translateY(${floatY}px)`, position: "relative" }}>
              <GlassCard width={CARD_W} height={CARD_H} radius={40}>
                {/* avatar + skeleton lines */}
                <div style={{ position: "absolute", top: 44, left: 44, display: "flex", alignItems: "center", gap: 26 }}>
                  <div
                    style={{
                      width: 124,
                      height: 124,
                      borderRadius: 62,
                      border: `4px solid ${theme.colors.accent}`,
                      background: theme.colors.accentSoft,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Icon name="spark" size={58} color={theme.colors.accent} />
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                    <div style={{ width: 280, height: 26, borderRadius: 13, background: alpha(theme.colors.white, 0.28) }} />
                    <div style={{ width: 190, height: 20, borderRadius: 10, background: alpha(theme.colors.white, 0.14) }} />
                  </div>
                </div>
                {/* thumbnails */}
                <div style={{ position: "absolute", top: 206, left: 44, right: 44, display: "flex", gap: 20 }}>
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      style={{
                        flex: 1,
                        height: 160,
                        borderRadius: 22,
                        background: alpha(theme.colors.white, 0.08),
                        border: `1px solid ${theme.colors.hairline}`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Icon name="play" size={40} color={alpha(theme.colors.white, 0.55)} />
                    </div>
                  ))}
                </div>
                {/* follow button */}
                <div
                  style={{
                    position: "absolute",
                    left: BTN.left,
                    right: BTN.right,
                    bottom: BTN.bottom,
                    height: BTN.h,
                    borderRadius: BTN.h / 2,
                    background: theme.colors.hero,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 18,
                    transform: `scale(${pressDip})`,
                    boxShadow: `0 0 70px ${theme.colors.glow}`,
                  }}
                >
                  <span style={{ fontFamily: theme.fonts.body, fontWeight: 700, fontSize: 52, letterSpacing: 0, color: theme.colors.white }}>
                    ফলো করুন
                  </span>
                  <div style={{ width: 52 * Math.min(1, done), opacity: Math.min(1, done), overflow: "hidden" }}>
                    <Icon name="check" size={52} color={theme.colors.white} draw={Math.min(1, done)} />
                  </div>
                </div>
                {/* ripple */}
                <div
                  style={{
                    position: "absolute",
                    left: CARD_W / 2 - 60,
                    top: CARD_H - BTN.bottom - BTN.h / 2 - 60,
                    width: 120,
                    height: 120,
                    borderRadius: 60,
                    border: `4px solid ${alpha(theme.colors.white, 0.8)}`,
                    opacity: ramp(frame, press, 3) * (1 - ripple),
                    transform: `scale(${1 + ripple * 3.6})`,
                  }}
                />
              </GlassCard>
              {/* cursor */}
              <div style={{ position: "absolute", left: cx, top: cy, opacity: cursorO, pointerEvents: "none" }}>
                <svg width="58" height="58" viewBox="0 0 24 24" style={{ filter: `drop-shadow(0 6px 10px ${theme.colors.shadow})` }}>
                  <path d="M2 2 L2 19 L7 14.5 L10.5 22 L13.5 20.7 L10 13.3 L17 13 Z" fill={theme.colors.white} stroke={theme.colors.bg} strokeWidth="1.4" strokeLinejoin="round" />
                </svg>
              </div>
            </div>
          </Entrance>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
