import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { Entrance, HighlightBar, SceneShell, Words, ramp, sp } from "../components/Motion";
import { GlassCard } from "../components/Glass";
import { alpha, theme } from "../theme";
import { EARLY } from "../timeline";
import type { SceneProps } from "./types";

const H = [0.16, 0.27, 0.38, 0.5, 0.64, 0.8, 0.98];
const CH = 540; // chart plot height
const BW = 78;
const BG = 30;

// cue 12: "মনে রাখবেন, দক্ষতা তৈরি হয় অনুশীলনে,"
export const S11Practice: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = t.at(12, 0, EARLY);
  const barStart = (i: number) => s + 12 + Math.round((t.cueDur(12) * 0.55 * i) / H.length);
  const plotW = H.length * BW + (H.length - 1) * BG;

  // কার্ভ: প্রতিটি বারের উপরের বিন্দু
  const tops = H.map((h, i) => ({ x: i * (BW + BG) + BW / 2, y: CH - h * CH }));
  const lineP = ramp(frame, barStart(0) + 6, Math.round(t.cueDur(12) * 0.55), theme.ease.inOut);
  const visible = Math.max(1, Math.round(lineP * (tops.length - 1)) + 1);
  const poly = tops.slice(0, visible).map((p) => `${p.x},${p.y}`).join(" ");

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 110, top: (1080 - 800) / 2 }}>
          <Entrance delay={s} y={50} from={0.94}>
            <GlassCard width={880} height={800} radius={40}>
              <div style={{ position: "absolute", left: 56, top: 42, fontFamily: theme.fonts.body, fontWeight: 600, fontSize: 40, letterSpacing: 0, color: theme.colors.textDim }}>
                দক্ষতা
              </div>
              <div style={{ position: "absolute", left: 100, top: 130, width: plotW, height: CH }}>
                {/* baseline */}
                <div style={{ position: "absolute", left: -20, right: -20, bottom: -2, height: 4, borderRadius: 2, background: theme.colors.hairline }} />
                {H.map((h, i) => {
                  const p = sp(frame, fps, barStart(i), theme.spring.snappy);
                  const last = i === H.length - 1;
                  return (
                    <div
                      key={i}
                      style={{
                        position: "absolute",
                        left: i * (BW + BG),
                        bottom: 0,
                        width: BW,
                        height: h * CH * Math.min(1, p),
                        borderRadius: 16,
                        background: last
                          ? theme.colors.hero
                          : `linear-gradient(180deg, ${alpha(theme.colors.accent, 0.55)}, ${alpha(theme.colors.accent, 0.18)})`,
                        boxShadow: last ? `0 0 60px ${theme.colors.glow}` : undefined,
                      }}
                    />
                  );
                })}
                <svg width={plotW} height={CH} style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
                  <polyline points={poly} fill="none" stroke={theme.colors.text} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" />
                  {tops.slice(0, visible).map((p, i) => (
                    <circle key={i} cx={p.x} cy={p.y} r={9} fill={theme.colors.text} />
                  ))}
                </svg>
              </div>
              <div style={{ position: "absolute", right: 56, bottom: 30, fontFamily: theme.fonts.body, fontWeight: 600, fontSize: 40, letterSpacing: 0, color: theme.colors.textDim }}>
                অনুশীলন
              </div>
            </GlassCard>
          </Entrance>
        </div>

        <div style={{ position: "absolute", left: 1040, right: 100, top: 0, bottom: 0, display: "flex", flexDirection: "column", justifyContent: "center", gap: 14 }}>
          <Words text="দক্ষতা তৈরি হয়" size={108} align="left" maxWidth={780} delay={s + 4} per={5} />
          <div style={{ position: "relative", alignSelf: "flex-start", marginLeft: 22 }}>
            <HighlightBar delay={s + 34} />
            <Words text="অনুশীলনে" size={132} align="left" delay={s + 24} per={4} style={{ position: "relative" }} />
          </div>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
