import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { Entrance, HighlightBar, LineMask, SceneShell, ramp, sp } from "../components/Motion";
import { Chip } from "../components/Glass";
import { theme } from "../theme";
import { EARLY } from "../timeline";
import type { SceneProps } from "./types";

const line: React.CSSProperties = {
  fontFamily: theme.fonts.display,
  fontWeight: 700,
  letterSpacing: 0,
  lineHeight: 1.4,
  whiteSpace: "nowrap",
  color: theme.colors.text,
};

// cue 6: "সবচেয়ে মজার বিষয় হলো, এর জন্য আপনাকে শুরুতেই প্রফেশনাল এডিটর হতে হবে না।"
export const S06Statement: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = t.at(6, 0, EARLY);
  const sweep = s + 26;
  const naPop = sp(frame, fps, s + 52, theme.spring.bouncy);
  const underline = ramp(frame, s + 58, 16);

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
          <Entrance delay={s}>
            <Chip size={42} color={theme.colors.accent}>
              সবচেয়ে মজার বিষয়
            </Chip>
          </Entrance>
          <div style={{ height: 6 }} />
          <LineMask delay={s + 6}>
            <span style={{ ...line, fontSize: 96, fontWeight: 600, color: theme.colors.textDim }}>শুরুতেই</span>
          </LineMask>
          <LineMask delay={s + 14}>
            <span style={{ position: "relative", display: "inline-block" }}>
              <HighlightBar delay={sweep} />
              <span style={{ ...line, position: "relative", fontSize: 150 }}>প্রফেশনাল এডিটর</span>
            </span>
          </LineMask>
          <LineMask delay={s + 22}>
            <span style={{ display: "inline-flex", alignItems: "baseline", gap: 38 }}>
              <span style={{ ...line, fontSize: 150 }}>হতে হবে</span>
              <span
                style={{
                  ...line,
                  fontSize: 170,
                  color: theme.colors.accent,
                  position: "relative",
                  display: "inline-block",
                  transform: `scale(${0.5 + 0.5 * naPop})`,
                  opacity: Math.min(1, naPop * 1.5),
                }}
              >
                না
                <span
                  style={{
                    position: "absolute",
                    left: 0,
                    right: 0,
                    bottom: 18,
                    height: 8,
                    borderRadius: 4,
                    background: theme.colors.accent,
                    transformOrigin: "left center",
                    transform: `scaleX(${underline})`,
                  }}
                />
              </span>
            </span>
          </LineMask>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
