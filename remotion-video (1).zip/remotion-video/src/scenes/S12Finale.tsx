import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { CLAMP, Entrance, SceneShell, Words, useFloat } from "../components/Motion";
import { Chip } from "../components/Glass";
import { Icon } from "../components/Icons";
import { alpha, theme } from "../theme";
import { EARLY } from "../timeline";
import type { SceneProps } from "./types";

const RECAP = ["কাটিং", "ট্রানজিশন", "সাবটাইটেল", "মিউজিক", "মোশন গ্রাফিক্স"];

// cue 13: "আর শুরুটা হতে পারে আজই!"
export const S12Finale: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const s = t.at(13, 0, EARLY);
  const hit = t.at(13, 0.36, 0); // "আজই!" বসার মুহূর্ত
  const ring = interpolate(frame, [hit, hit + 34], [0.3, 1.8], { easing: theme.ease.out, ...CLAMP });
  const ringO = interpolate(frame, [hit, hit + 6, hit + 34], [0, 0.7, 0], CLAMP);
  const idle = useFloat(0, 5);

  return (
    <SceneShell duration={t.duration} exit={false}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div
          style={{
            position: "absolute",
            width: 760,
            height: 760,
            borderRadius: "50%",
            border: `3px solid ${alpha(theme.colors.accent, 0.8)}`,
            opacity: ringO,
            transform: `translateY(-70px) scale(${ring})`,
          }}
        />
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 0, transform: `translateY(${idle}px)` }}>
          <Words text="শুরুটা হতে পারে" size={112} weight={600} delay={s} per={5} />
          <Words
            text="আজই!"
            size={300}
            delay={hit - 6}
            per={4}
            lineHeight={1.2}
            emphasis={{ 0: { color: theme.colors.hero, glow: true, pop: true } }}
          />
          <div style={{ display: "flex", gap: 22, marginTop: 34 }}>
            {RECAP.map((label, i) => (
              <Entrance key={i} delay={hit + 14 + i * 4} y={26} config={theme.spring.snappy}>
                <Chip size={40} color={theme.colors.accent}>
                  <Icon name="check" size={34} color={theme.colors.accent} />
                  {label}
                </Chip>
              </Entrance>
            ))}
          </div>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
