import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { CLAMP, Entrance, SceneShell, Words, sp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { alpha, theme } from "../theme";
import { EARLY } from "../timeline";
import type { SceneProps } from "./types";

type P = [number, number];
const bez = (a: P, b: P, c: P, d: P, u: number): P => {
  const m = 1 - u;
  return [
    m * m * m * a[0] + 3 * m * m * u * b[0] + 3 * m * u * u * c[0] + u * u * u * d[0],
    m * m * m * a[1] + 3 * m * m * u * b[1] + 3 * m * u * u * c[1] + u * u * u * d[1],
  ];
};
const SEG1: [P, P, P, P] = [[220, 860], [560, 860], [580, 650], [960, 700]];
const SEG2: [P, P, P, P] = [[960, 700], [1340, 750], [1420, 600], [1700, 600]];
const pointAt = (u: number): P => (u < 0.5 ? bez(...SEG1, u * 2) : bez(...SEG2, (u - 0.5) * 2));
const SAMPLES = 120;

// cue 9: "আপনার ভিডিও এডিটিংয়ের যাত্রা।"
export const S09Journey: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = t.at(9, 0, EARLY);
  const drawStart = s + 8;
  const drawEnd = s + 56;
  const u = interpolate(frame, [drawStart, drawEnd], [0, 1], { easing: theme.ease.inOut, ...CLAMP });
  const count = Math.max(1, Math.round(u * SAMPLES));
  const pts = Array.from({ length: count + 1 }, (_, k) => pointAt((u * k) / count));
  const d = pts.map((p, k) => `${k === 0 ? "M" : "L"} ${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(" ");
  const tip = pointAt(u);
  const endPop = sp(frame, fps, drawEnd - 4, theme.spring.bouncy);
  const mile = [0.34, 0.67].map((m) => sp(frame, fps, drawStart + (drawEnd - drawStart) * m, theme.spring.snappy));

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill>
        <div style={{ position: "absolute", top: 190, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
          <Words text="আপনার ভিডিও এডিটিংয়ের যাত্রা" size={128} maxWidth={1500} delay={s} per={4} emphasis={{ 2: { color: theme.colors.accent } }} />
        </div>

        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          <path
            d={`M ${SEG1[0][0]} ${SEG1[0][1]} C ${SEG1[1].join(" ")} ${SEG1[2].join(" ")} ${SEG1[3].join(" ")} C ${SEG2[1].join(" ")} ${SEG2[2].join(" ")} ${SEG2[3].join(" ")}`}
            fill="none"
            stroke={theme.colors.hairline}
            strokeWidth={6}
            strokeDasharray="2 16"
            strokeLinecap="round"
          />
          <path
            d={d}
            fill="none"
            stroke={theme.colors.accent}
            strokeWidth={10}
            strokeLinecap="round"
            strokeLinejoin="round"
            style={{ filter: `drop-shadow(0 0 14px ${theme.colors.glowAccent})` }}
          />
          <circle cx={SEG1[0][0]} cy={SEG1[0][1]} r={18} fill={theme.colors.accent} />
          {[0.34, 0.67].map((m, k) => {
            const p = pointAt(m);
            return <circle key={k} cx={p[0]} cy={p[1]} r={14 * Math.min(1, mile[k])} fill={theme.colors.text} />;
          })}
          {u < 0.999 && <circle cx={tip[0]} cy={tip[1]} r={16} fill={theme.colors.text} />}
        </svg>

        <div style={{ position: "absolute", left: SEG1[0][0] - 60, top: SEG1[0][1] + 34, width: 120, textAlign: "center" }}>
          <Entrance delay={s + 6} y={20}>
            <span style={{ fontFamily: theme.fonts.body, fontWeight: 600, fontSize: 42, letterSpacing: 0, color: theme.colors.textDim }}>
              শুরু
            </span>
          </Entrance>
        </div>

        <div
          style={{
            position: "absolute",
            left: SEG2[3][0] - 64,
            top: SEG2[3][1] - 64,
            width: 128,
            height: 128,
            borderRadius: 64,
            background: theme.colors.hero,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: `0 0 80px ${theme.colors.glow}`,
            transform: `scale(${Math.min(1.1, 0.3 + 0.7 * endPop)})`,
            opacity: Math.min(1, endPop * 2),
          }}
        >
          <Icon name="spark" size={66} color={theme.colors.white} />
        </div>
        <div
          style={{
            position: "absolute",
            left: SEG2[3][0] - 64 - 14,
            top: SEG2[3][1] - 64 - 14,
            width: 156,
            height: 156,
            borderRadius: 78,
            border: `3px solid ${alpha(theme.colors.hero, 0.5)}`,
            opacity: interpolate(frame, [drawEnd, drawEnd + 14, drawEnd + 30], [0, 0.8, 0], CLAMP),
            transform: `scale(${interpolate(frame, [drawEnd, drawEnd + 30], [0.9, 1.5], { easing: theme.ease.out, ...CLAMP })})`,
          }}
        />
      </AbsoluteFill>
    </SceneShell>
  );
};
