import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { CLAMP, SceneShell, Words, ramp } from "../components/Motion";
import { alpha, theme } from "../theme";
import type { SceneProps } from "./types";

// cue 1: "ভিডিও এডিটর না হয়েও ভিডিও এডিট করা এখন আর কঠিন কিছু না!"
export const S01Hook: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const ringScale = interpolate(frame, [0, 46], [0.35, 1.5], { easing: theme.ease.out, ...CLAMP });
  const ringOpacity = interpolate(frame, [0, 8, 46], [0, 0.55, 0], CLAMP);
  const rowC = t.at(1, 0.5, 0); // "কঠিন কিছু না!" অংশ
  const strike = ramp(frame, rowC + 14, 12);

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div
          style={{
            position: "absolute",
            width: 980,
            height: 980,
            borderRadius: "50%",
            border: `3px solid ${alpha(theme.colors.accent, 0.7)}`,
            opacity: ringOpacity,
            transform: `scale(${ringScale})`,
          }}
        />
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
          <Words text="এডিটর না হয়েও" size={86} weight={600} color={theme.colors.textDim} delay={0} per={4} />
          <Words
            text="ভিডিও এডিট"
            size={210}
            delay={9}
            per={5}
            emphasis={{ 1: { color: theme.colors.hero, glow: true } }}
          />
          <div style={{ display: "flex", alignItems: "center", gap: 40 }}>
            <div style={{ position: "relative" }}>
              <Words text="কঠিন" size={124} weight={600} color={theme.colors.textDim} delay={rowC} per={3} />
              <div
                style={{
                  position: "absolute",
                  left: -12,
                  right: -12,
                  top: "50%",
                  height: 9,
                  borderRadius: 6,
                  background: theme.colors.accent,
                  transformOrigin: "left center",
                  transform: `scaleX(${strike})`,
                }}
              />
            </div>
            <Words text="কিছু না!" size={124} delay={rowC + 10} per={4} />
          </div>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
