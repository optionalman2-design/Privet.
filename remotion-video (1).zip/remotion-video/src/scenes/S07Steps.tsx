import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { CLAMP, Entrance, SceneShell, ramp, sp } from "../components/Motion";
import { Chip } from "../components/Glass";
import { Icon } from "../components/Icons";
import { alpha, theme } from "../theme";
import { EARLY } from "../timeline";
import type { SceneProps } from "./types";

const STEPS = ["একটু শেখার আগ্রহ", "সঠিক টুল", "নিয়মিত অনুশীলন"];
const XS = [360, 960, 1560];
const Y = 470;
const R = 62;

// cue 7: "শুধু প্রয়োজন একটু শেখার আগ্রহ, সঠিক টুল আর নিয়মিত অনুশীলন।"
export const S07Steps: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const n = STEPS.length;
  const starts = STEPS.map((_, i) => t.at(7, i / n, EARLY));

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill>
        <div style={{ position: "absolute", top: 150, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
          <Entrance delay={t.at(7, 0, EARLY)}>
            <Chip size={48} color={theme.colors.accent}>
              শুধু প্রয়োজন
            </Chip>
          </Entrance>
        </div>

        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          <line x1={XS[0]} y1={Y} x2={XS[2]} y2={Y} stroke={theme.colors.hairline} strokeWidth={6} strokeLinecap="round" />
          {XS.slice(1).map((x, k) => {
            const p = ramp(frame, starts[k + 1] - 16, 16);
            return (
              <line
                key={k}
                x1={XS[k]}
                y1={Y}
                x2={XS[k] + (x - XS[k]) * p}
                y2={Y}
                stroke={theme.colors.hero}
                strokeWidth={6}
                strokeLinecap="round"
              />
            );
          })}
        </svg>

        {STEPS.map((label, i) => {
          const pop = sp(frame, fps, starts[i], theme.spring.bouncy);
          const check = interpolate(frame, [starts[i] + 8, starts[i] + 20], [0, 1], { easing: theme.ease.out, ...CLAMP });
          return (
            <React.Fragment key={i}>
              <div
                style={{
                  position: "absolute",
                  left: XS[i] - R,
                  top: Y - R,
                  width: R * 2,
                  height: R * 2,
                  borderRadius: R,
                  background: alpha(theme.colors.accent, 0.18 + 0.82 * check),
                  border: `3px solid ${theme.colors.accent}`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  transform: `scale(${Math.min(1.12, 0.4 + 0.6 * pop)})`,
                  opacity: Math.min(1, pop * 1.5),
                  boxShadow: `0 0 ${50 * check}px ${theme.colors.glowAccent}`,
                }}
              >
                <span
                  style={{
                    position: "absolute",
                    fontFamily: theme.fonts.body,
                    fontWeight: 700,
                    fontSize: 46,
                    letterSpacing: 0,
                    color: theme.colors.accent,
                    opacity: 1 - check,
                  }}
                >
                  {`0${i + 1}`}
                </span>
                <div style={{ opacity: check }}>
                  <Icon name="check" size={70} color={theme.colors.bg} draw={check} />
                </div>
              </div>
              <div
                style={{
                  position: "absolute",
                  left: XS[i] - 280,
                  width: 560,
                  top: Y + 110,
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <Entrance delay={starts[i] + 4} y={30} config={theme.spring.snappy}>
                  <span
                    style={{
                      fontFamily: theme.fonts.display,
                      fontWeight: 700,
                      fontSize: 68,
                      lineHeight: 1.35,
                      letterSpacing: 0,
                      whiteSpace: "nowrap",
                      color: theme.colors.text,
                    }}
                  >
                    {label}
                  </span>
                </Entrance>
              </div>
            </React.Fragment>
          );
        })}
      </AbsoluteFill>
    </SceneShell>
  );
};
