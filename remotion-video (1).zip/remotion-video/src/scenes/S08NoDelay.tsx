import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { CLAMP, SceneShell, Words, ramp } from "../components/Motion";
import { alpha, theme } from "../theme";
import { EARLY } from "../timeline";
import type { SceneProps } from "./types";

// cue 8: "তাই আর দেরি কেন? আজ থেকেই শুরু করুন"
export const S08NoDelay: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const a = t.at(8, 0, EARLY);
  const b = t.at(8, 0.5, 0);
  const hit = a + 6 * 2 + 4; // "কেন?" যে মুহূর্তে বসে
  const ring = interpolate(frame, [hit, hit + 30], [0.4, 1.7], { easing: theme.ease.out, ...CLAMP });
  const ringO = interpolate(frame, [hit, hit + 6, hit + 30], [0, 0.6, 0], CLAMP);
  const underline = ramp(frame, b + 16, 16);

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div
          style={{
            position: "absolute",
            width: 900,
            height: 900,
            borderRadius: "50%",
            border: `3px solid ${alpha(theme.colors.hero, 0.8)}`,
            opacity: ringO,
            transform: `scale(${ring})`,
          }}
        />
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 18 }}>
          <Words
            text="আর দেরি কেন?"
            size={210}
            delay={a}
            per={6}
            emphasis={{ 2: { color: theme.colors.hero, glow: true, pop: true } }}
          />
          <div style={{ position: "relative" }}>
            <Words
              text="আজ থেকেই শুরু করুন"
              size={112}
              weight={600}
              delay={b}
              per={5}
              emphasis={{ 3: { color: theme.colors.accent } }}
            />
            <div
              style={{
                position: "absolute",
                left: 0,
                right: 0,
                bottom: 4,
                height: 7,
                borderRadius: 4,
                background: alpha(theme.colors.accent, 0.8),
                transformOrigin: "left center",
                transform: `scaleX(${underline})`,
              }}
            />
          </div>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
