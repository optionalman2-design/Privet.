import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { CLAMP, Entrance, SceneShell, ramp, sp, useFloat } from "../components/Motion";
import { Chip } from "../components/Glass";
import { Icon } from "../components/Icons";
import { alpha, theme } from "../theme";
import { EARLY } from "../timeline";
import { FOUR_ITEMS } from "./S03FourThings";
import type { SceneProps } from "./types";

const CX = 960;
const CY = 560;
const NODES = [
  { x: CX - 470, y: CY - 235 },
  { x: CX + 470, y: CY - 235 },
  { x: CX - 470, y: CY + 235 },
  { x: CX + 470, y: CY + 235 },
];
const ORDER = [0, 1, 3, 2]; // ঘড়ির কাঁটার ক্রমে উঠে আসে

// cue 4: "আকর্ষণীয় মোশন গ্রাফিক্স— সবকিছুই করা সম্ভব কয়েকটি সহজ টুল ব্যবহার করে।"
export const S04Hub: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = t.at(4, 0, EARLY);
  const breathe = 1 + Math.sin(frame / 22) * 0.015;
  const pulse = interpolate((frame % 60) / 60, [0, 1], [0, 1]);
  const hubY = useFloat(0, 3);

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill>
        <div style={{ position: "absolute", top: 70, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
          <Entrance delay={s + 30}>
            <Chip size={44} color={theme.colors.text}>
              কয়েকটি সহজ টুল
            </Chip>
          </Entrance>
        </div>

        {/* spokes */}
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          {NODES.map((n, i) => {
            const order = ORDER.indexOf(i);
            const d0 = s + 12 + order * 5;
            const p = ramp(frame, d0, 18);
            const ex = CX + (n.x - CX) * p;
            const ey = CY + (n.y - CY) * p;
            const travel = ((frame * 0.012 + i * 0.27) % 1);
            return (
              <g key={i}>
                <line x1={CX} y1={CY} x2={ex} y2={ey} stroke={alpha(theme.colors.accent, 0.55)} strokeWidth={3} strokeLinecap="round" />
                {p > 0.98 && (
                  <circle
                    cx={CX + (n.x - CX) * travel}
                    cy={CY + (n.y - CY) * travel}
                    r={7}
                    fill={theme.colors.accent}
                  />
                )}
              </g>
            );
          })}
        </svg>

        {/* hub */}
        <div
          style={{
            position: "absolute",
            left: CX - 150,
            top: CY - 150 + hubY,
            width: 300,
            height: 300,
            transform: `scale(${(0.4 + 0.6 * sp(frame, fps, s, theme.spring.bouncy)) * breathe})`,
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: -20 - 40 * pulse,
              borderRadius: "50%",
              border: `3px solid ${alpha(theme.colors.hero, 0.5 * (1 - pulse))}`,
            }}
          />
          <div
            style={{
              width: 300,
              height: 300,
              borderRadius: 150,
              background: theme.colors.hero,
              boxShadow: `0 0 90px ${theme.colors.glow}, 0 0 180px ${alpha(theme.colors.hero, 0.3)}`,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 4,
            }}
          >
            <Icon name="spark" size={64} color={theme.colors.white} />
            <div
              style={{
                fontFamily: theme.fonts.display,
                fontWeight: 700,
                fontSize: 48,
                lineHeight: 1.25,
                letterSpacing: 0,
                textAlign: "center",
                color: theme.colors.white,
              }}
            >
              মোশন
              <br />
              গ্রাফিক্স
            </div>
          </div>
        </div>

        {/* satellites */}
        {NODES.map((n, i) => {
          const order = ORDER.indexOf(i);
          const d = s + 22 + order * 5;
          const item = FOUR_ITEMS[i];
          return (
            <div key={i} style={{ position: "absolute", left: n.x - 230, top: n.y - 56, width: 460, height: 112 }}>
              <Entrance delay={d} y={30} config={theme.spring.snappy}>
                <div
                  style={{
                    height: 112,
                    borderRadius: 56,
                    display: "flex",
                    alignItems: "center",
                    gap: 22,
                    padding: "0 34px",
                    backgroundColor: theme.colors.bgAlt,
                    backgroundImage: `linear-gradient(155deg, ${theme.colors.glassHi}, ${theme.colors.glassLo})`,
                    border: `2px solid ${theme.colors.glassBorder}`,
                    boxShadow: `0 30px 60px -24px ${theme.colors.shadow}`,
                  }}
                >
                  <Icon name={item.icon} size={52} color={theme.colors.accent} />
                  <span
                    style={{
                      fontFamily: theme.fonts.body,
                      fontWeight: 700,
                      fontSize: 42,
                      letterSpacing: 0,
                      whiteSpace: "nowrap",
                      color: theme.colors.text,
                    }}
                  >
                    {item.label}
                  </span>
                </div>
              </Entrance>
            </div>
          );
        })}
      </AbsoluteFill>
    </SceneShell>
  );
};
