import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { CLAMP, Entrance, SceneShell, Words, sp, useFloat } from "../components/Motion";
import { GlassCard } from "../components/Glass";
import { Icon } from "../components/Icons";
import { VideoArt } from "../components/VideoArt";
import { alpha, theme } from "../theme";
import { EARLY } from "../timeline";
import type { SceneProps } from "./types";

const WW = 940;
const WH = 660;
const HEADER = 58;
const PREVIEW = 330;

const TRACKS = [
  { clips: [{ x: 3, w: 28 }, { x: 33, w: 20 }, { x: 55, w: 40 }], kind: "accent" },
  { clips: [{ x: 3, w: 40 }, { x: 46, w: 30 }], kind: "hero" },
  { clips: [{ x: 14, w: 22 }, { x: 40, w: 22 }, { x: 66, w: 28 }], kind: "plain" },
] as const;

// cue 5: "আপনি চাইলে CapCut-এর মতো অ্যাপ দিয়ে সহজেই ভিডিও এডিটিং শুরু করতে পারেন।"
export const S05CapCut: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = t.at(5, 0, EARLY);
  const play = interpolate(frame, [s + 24, t.duration - 14], [8, 90], { easing: theme.ease.inOut, ...CLAMP });
  const floatY = useFloat(2, 3);

  const clipColor = (kind: string): string =>
    kind === "accent"
      ? alpha(theme.colors.accent, 0.6)
      : kind === "hero"
        ? alpha(theme.colors.hero, 0.7)
        : alpha(theme.colors.white, 0.2);

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 70, padding: "0 100px" }}>
          <div style={{ width: 660, flexShrink: 0, display: "flex", flexDirection: "column", gap: 18 }}>
            <Words
              text="CapCut-এর মতো অ্যাপ"
              size={96}
              align="left"
              maxWidth={660}
              delay={s}
              per={5}
              emphasis={{ 0: { color: theme.colors.accent } }}
            />
            <Words
              text="ভিডিও এডিটিং শুরু"
              size={56}
              weight={500}
              align="left"
              color={theme.colors.textDim}
              delay={s + 18}
              per={4}
            />
          </div>

          <Entrance delay={s + 6} y={60} from={0.92}>
            <div style={{ transform: `translateY(${floatY}px)` }}>
              <GlassCard width={WW} height={WH} radius={32}>
                <div
                  style={{
                    height: HEADER,
                    display: "flex",
                    alignItems: "center",
                    padding: "0 24px",
                    borderBottom: `1px solid ${theme.colors.hairline}`,
                    position: "relative",
                  }}
                >
                  <div style={{ display: "flex", gap: 12 }}>
                    {[0, 1, 2].map((i) => (
                      <div key={i} style={{ width: 14, height: 14, borderRadius: 7, background: alpha(theme.colors.white, 0.28) }} />
                    ))}
                  </div>
                  <div
                    style={{
                      position: "absolute",
                      left: 0,
                      right: 0,
                      textAlign: "center",
                      fontFamily: theme.fonts.body,
                      fontWeight: 600,
                      fontSize: 28,
                      letterSpacing: 0,
                      color: theme.colors.textDim,
                    }}
                  >
                    CapCut
                  </div>
                </div>

                <div style={{ position: "relative", width: WW, height: PREVIEW, overflow: "hidden" }}>
                  <VideoArt width={WW} height={PREVIEW} id="s5" />
                  <div
                    style={{
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      width: 96,
                      height: 96,
                      marginLeft: -48,
                      marginTop: -48,
                      borderRadius: 48,
                      background: alpha(theme.colors.bg, 0.55),
                      border: `2px solid ${alpha(theme.colors.white, 0.4)}`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Icon name="play" size={40} color={theme.colors.white} style={{ marginLeft: 6 }} />
                  </div>
                </div>

                <div style={{ position: "relative", padding: "20px 24px", height: WH - HEADER - PREVIEW }}>
                  {TRACKS.map((tr, r) => (
                    <div key={r} style={{ position: "relative", height: 54, marginBottom: 16 }}>
                      {tr.clips.map((c, k) => {
                        const p = sp(frame, fps, s + 16 + r * 6 + k * 4, theme.spring.snappy);
                        return (
                          <div
                            key={k}
                            style={{
                              position: "absolute",
                              left: `${c.x}%`,
                              width: `${c.w}%`,
                              top: 0,
                              height: 54,
                              borderRadius: 12,
                              background: clipColor(tr.kind),
                              border: `1px solid ${alpha(theme.colors.white, 0.2)}`,
                              transformOrigin: "left center",
                              transform: `scaleX(${Math.min(1, p)})`,
                              opacity: Math.min(1, p * 1.5),
                            }}
                          />
                        );
                      })}
                    </div>
                  ))}
                  <div
                    style={{
                      position: "absolute",
                      top: 8,
                      bottom: 12,
                      left: `calc(24px + (100% - 48px) * ${play / 100})`,
                      width: 4,
                      borderRadius: 2,
                      background: theme.colors.text,
                      boxShadow: `0 0 20px ${alpha(theme.colors.text, 0.5)}`,
                    }}
                  />
                </div>
              </GlassCard>
            </div>
          </Entrance>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
