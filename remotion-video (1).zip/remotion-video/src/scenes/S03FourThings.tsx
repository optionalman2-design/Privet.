import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { CLAMP, Entrance, SceneShell, useFloat } from "../components/Motion";
import { GlassCard } from "../components/Glass";
import { Icon } from "../components/Icons";
import type { IconName } from "../components/Icons";
import { alpha, theme } from "../theme";
import { EARLY } from "../timeline";
import type { SceneProps } from "./types";

export const FOUR_ITEMS: { icon: IconName; label: string }[] = [
  { icon: "cut", label: "ভিডিও কাটিং" },
  { icon: "transition", label: "সুন্দর ট্রানজিশন" },
  { icon: "subtitle", label: "বাংলা সাবটাইটেল" },
  { icon: "music", label: "ব্যাকগ্রাউন্ড মিউজিক" },
];

// cue 3: কাটিং, ট্রানজিশন, সাবটাইটেল, মিউজিক — cue-র সময়ে সমান ব্যবধানে
export const S03FourThings: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const n = FOUR_ITEMS.length;
  const starts = FOUR_ITEMS.map((_, i) => t.at(3, i / n, EARLY));

  const focus = (i: number): number => {
    const up = interpolate(frame, [starts[i], starts[i] + 8], [0, 1], { easing: theme.ease.out, ...CLAMP });
    const down =
      i < n - 1
        ? interpolate(frame, [starts[i + 1], starts[i + 1] + 8], [0, 1], { easing: theme.ease.out, ...CLAMP })
        : 0;
    return up * (1 - down);
  };

  return (
    <SceneShell duration={t.duration}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div style={{ display: "flex", gap: 38 }}>
          {FOUR_ITEMS.map((item, i) => (
            <CardItem key={i} index={i} total={n} delay={starts[i]} focus={focus(i)} icon={item.icon} label={item.label} />
          ))}
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};

const CardItem: React.FC<{
  index: number;
  total: number;
  delay: number;
  focus: number;
  icon: IconName;
  label: string;
}> = ({ index, total, delay, focus, icon, label }) => {
  const floatY = useFloat(index * 1.3, 4);
  return (
    <Entrance delay={delay} y={70} from={0.9} config={theme.spring.snappy}>
      <div style={{ transform: `translateY(${floatY}px) scale(${1 + 0.035 * focus})` }}>
        <GlassCard width={390} height={520} active={focus}>
          <div style={{ position: "absolute", top: 34, left: 38, right: 38, display: "flex", justifyContent: "space-between" }}>
            <span style={{ fontFamily: theme.fonts.body, fontSize: 34, fontWeight: 600, color: theme.colors.textDim }}>
              {`0${index + 1} / 0${total}`}
            </span>
          </div>
          <div style={{ position: "absolute", top: 118, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
            <div
              style={{
                width: 188,
                height: 188,
                borderRadius: 94,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: focus > 0.01 ? alpha(theme.colors.hero, 0.18 + 0.5 * focus) : theme.colors.glassHi,
                border: `2px solid ${alpha(theme.colors.white, 0.18)}`,
              }}
            >
              <Icon name={icon} size={92} color={theme.colors.text} />
            </div>
          </div>
          <div
            style={{
              position: "absolute",
              left: 28,
              right: 28,
              bottom: 44,
              textAlign: "center",
              fontFamily: theme.fonts.body,
              fontSize: 58,
              fontWeight: 700,
              lineHeight: 1.3,
              letterSpacing: 0,
              color: theme.colors.text,
            }}
          >
            {label}
          </div>
        </GlassCard>
      </div>
    </Entrance>
  );
};
