// Auto-generated from public/subtitles.srt — the ONLY content + timing source.
export type Cue = { id: number; startMs: number; endMs: number; text: string };

export const SRT_RAW: string = "1\n00:00:00,000 --> 00:00:03,550\nভিডিও এডিটর না হয়েও ভিডিও এডিট করা\nএখন আর কঠিন কিছু না!\n\n2\n00:00:03,550 --> 00:00:07,450\nকারণ, এখন AI-এর যুগে আপনি খুব সহজেই\nনিজের ভিডিওকে প্রফেশনাল লুকে রূপ দিতে পারবেন।\n\n3\n00:00:07,450 --> 00:00:12,550\nভিডিও কাটিং, সুন্দর ট্রানজিশন, বাংলা সাবটাইটেল,\nব্যাকগ্রাউন্ড মিউজিক থেকে শুরু করে\n\n4\n00:00:12,550 --> 00:00:16,450\nআকর্ষণীয় মোশন গ্রাফিক্স—\nসবকিছুই করা সম্ভব কয়েকটি সহজ টুল ব্যবহার করে।\n\n5\n00:00:16,450 --> 00:00:20,050\nআপনি চাইলে CapCut-এর মতো অ্যাপ দিয়ে\nসহজেই ভিডিও এডিটিং শুরু করতে পারেন।\n\n6\n00:00:20,050 --> 00:00:23,850\nসবচেয়ে মজার বিষয় হলো, এর জন্য\nআপনাকে শুরুতেই প্রফেশনাল এডিটর হতে হবে না।\n\n7\n00:00:23,850 --> 00:00:27,450\nশুধু প্রয়োজন একটু শেখার আগ্রহ,\nসঠিক টুল আর নিয়মিত অনুশীলন।\n\n8\n00:00:27,450 --> 00:00:30,650\nতাই আর দেরি কেন? আজ থেকেই শুরু করুন\n\n9\n00:00:30,650 --> 00:00:33,150\nআপনার ভিডিও এডিটিংয়ের যাত্রা।\n\n10\n00:00:33,150 --> 00:00:37,350\nআর AI দিয়ে ভিডিও তৈরি ও এডিটিং শিখতে চাইলে\n\n11\n00:00:37,350 --> 00:00:40,200\nপেজটি ফলো করুন।\n\n12\n00:00:40,200 --> 00:00:45,100\nমনে রাখবেন, দক্ষতা তৈরি হয় অনুশীলনে,\n\n13\n00:00:45,100 --> 00:00:51,200\nআর শুরুটা হতে পারে আজই!\n";

const parseTime = (s: string): number => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error("Bad SRT timestamp: " + s);
  return ((Number(m[1]) * 60 + Number(m[2])) * 60 + Number(m[3])) * 1000 + Number(m[4]);
};

export const parseSrt = (input: string): Cue[] =>
  input
    .replace(/^\uFEFF/, "")
    .replace(/\r/g, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split("\n");
      const [a, b] = lines[1].split("-->");
      return {
        id: Number(lines[0]),
        startMs: parseTime(a),
        endMs: parseTime(b),
        text: lines.slice(2).join(" ").trim(),
      };
    });

export const CUES: Cue[] = parseSrt(SRT_RAW);
export const TOTAL_MS: number = CUES[CUES.length - 1].endMs;
export const msToFrame = (ms: number, fps: number): number => Math.round((ms * fps) / 1000);
export const TOTAL_FRAMES = (fps: number): number => msToFrame(TOTAL_MS, fps);
export const getCue = (id: number): Cue => {
  const c = CUES.find((x) => x.id === id);
  if (!c) throw new Error("Cue not found: " + id);
  return c;
};
