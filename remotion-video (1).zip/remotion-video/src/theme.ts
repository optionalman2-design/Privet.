// theme.ts — একমাত্র design source: রং, ফন্ট, easing, spring। কম্পোনেন্টে hex লেখা নিষেধ।
import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// বাংলা যুক্তাক্ষর ও কার-চিহ্ন ঠিক দেখানোর জন্য Hind Siliguri (bengali + latin subset)
const { fontFamily } = loadFont("normal", {
  weights: ["400", "500", "600", "700"],
  subsets: ["bengali", "latin"],
});

export const alpha = (hex: string, a: number): string => {
  const n = parseInt(hex.replace("#", ""), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};

// ব্যবহারকারীর নির্বাচিত palette #1 — "মিডনাইট ইলেকট্রিক"
const palette = {
  bg: "#0B1020",
  hero: "#4F7CFF",
  accent: "#00E5C3",
  text: "#F2F5FF",
} as const;

const support = {
  bgAlt: "#121A36",
  surface: "#1A2448",
  textDim: "#9CA8CF",
  white: "#FFFFFF",
  black: "#000000",
} as const;

export const theme = {
  video: { width: 1920, height: 1080, fps: 30 },
  colors: {
    ...palette,
    ...support,
    glow: alpha(palette.hero, 0.55),
    glowAccent: alpha(palette.accent, 0.4),
    heroSoft: alpha(palette.hero, 0.22),
    accentSoft: alpha(palette.accent, 0.18),
    glassHi: alpha(support.white, 0.11),
    glassLo: alpha(support.white, 0.04),
    glassBorder: alpha(support.white, 0.16),
    hairline: alpha(support.white, 0.12),
    shadow: alpha(support.black, 0.55),
  },
  fonts: {
    display: fontFamily,
    body: fontFamily,
  },
  radius: { card: 36, small: 20, pill: 999 },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // প্রবেশ
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // চলাচল
    in: Easing.bezier(0.7, 0, 0.84, 0), // শুধু exit
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;
