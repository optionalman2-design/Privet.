// ভয়েসওভার preview flag।
// VOICEOVER_PREVIEW = false করলে Studio-তেও অডিও বন্ধ থাকবে।
export const VOICEOVER_PREVIEW = true;
// render-এর সময় ডিফল্টে বন্ধ। (ভয়েসওভারসহ render চাইলে true করুন)
export const VOICEOVER_IN_RENDER = false;
