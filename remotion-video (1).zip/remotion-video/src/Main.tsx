import React, { useMemo } from "react";
import { AbsoluteFill, Sequence, useVideoConfig } from "remotion";
import { PreviewAudio } from "./audio/PreviewAudio";
import { Sfx, buildSfxCues } from "./audio/Sfx";
import { BgMesh, Grade, Grain, Vignette } from "./components/Layers";
import { S01Hook } from "./scenes/S01Hook";
import { S02AiLook } from "./scenes/S02AiLook";
import { S03FourThings } from "./scenes/S03FourThings";
import { S04Hub } from "./scenes/S04Hub";
import { S05CapCut } from "./scenes/S05CapCut";
import { S06Statement } from "./scenes/S06Statement";
import { S07Steps } from "./scenes/S07Steps";
import { S08NoDelay } from "./scenes/S08NoDelay";
import { S09Journey } from "./scenes/S09Journey";
import { S10Follow } from "./scenes/S10Follow";
import { S11Practice } from "./scenes/S11Practice";
import { S12Finale } from "./scenes/S12Finale";
import type { SceneProps } from "./scenes/types";
import { buildTimeline } from "./timeline";
import { theme } from "./theme";

// SCENE_DEFS (timeline.ts)-এর ক্রমে
const SCENES: React.FC<SceneProps>[] = [
  S01Hook,
  S02AiLook,
  S03FourThings,
  S04Hub,
  S05CapCut,
  S06Statement,
  S07Steps,
  S08NoDelay,
  S09Journey,
  S10Follow,
  S11Practice,
  S12Finale,
];

export const Main: React.FC = () => {
  const { fps } = useVideoConfig();
  const timeline = useMemo(() => buildTimeline(fps), [fps]);
  const sfxCues = useMemo(() => buildSfxCues(timeline), [timeline]);

  return (
    <AbsoluteFill style={{ backgroundColor: theme.colors.bg, fontFamily: theme.fonts.body }}>
      <BgMesh />
      {timeline.map((t, i) => {
        const Scene = SCENES[i];
        return (
          <Sequence key={t.id} name={t.id} from={t.from} durationInFrames={t.duration}>
            <Scene t={t} />
          </Sequence>
        );
      })}
      <Grade />
      <Grain />
      <Vignette />
      <Sfx cues={sfxCues} />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
