// public/subtitles.srt বদলালে এটি চালান: node scripts/gen-srt-module.mjs
// SRT-ই একমাত্র content + timing source; src/srt.ts এখান থেকেই তৈরি হয়।
import fs from "node:fs";

const raw = fs.readFileSync("public/subtitles.srt", "utf8");
const body = `// Auto-generated from public/subtitles.srt — the ONLY content + timing source.
export type Cue = { id: number; startMs: number; endMs: number; text: string };

export const SRT_RAW: string = ${JSON.stringify(raw)};

const parseTime = (s: string): number => {
  const m = s.trim().match(/(\\d+):(\\d+):(\\d+)[,.](\\d+)/);
  if (!m) throw new Error("Bad SRT timestamp: " + s);
  return ((Number(m[1]) * 60 + Number(m[2])) * 60 + Number(m[3])) * 1000 + Number(m[4]);
};

export const parseSrt = (input: string): Cue[] =>
  input
    .replace(/^\\uFEFF/, "")
    .replace(/\\r/g, "")
    .trim()
    .split(/\\n\\s*\\n/)
    .map((block) => {
      const lines = block.split("\\n");
      const [a, b] = lines[1].split("-->");
      return {
        id: Number(lines[0]),
        startMs: parseTime(a),
        endMs: parseTime(b),
        text: lines.slice(2).join(" ").trim(),
      };
    });

export const CUES: Cue[] = parseSrt(SRT_RAW);
export const TOTAL_MS: number = CUES[CUES.length - 1].endMs;
export const msToFrame = (ms: number, fps: number): number => Math.round((ms * fps) / 1000);
export const TOTAL_FRAMES = (fps: number): number => msToFrame(TOTAL_MS, fps);
export const getCue = (id: number): Cue => {
  const c = CUES.find((x) => x.id === id);
  if (!c) throw new Error("Cue not found: " + id);
  return c;
};
`;
fs.writeFileSync("src/srt.ts", body);
console.log("src/srt.ts written");
