// UI-ধাঁচের ছোট SFX তৈরি (কোনো ডাউনলোড নয়, deterministic)। চালান: node scripts/make-sfx.mjs
import fs from "node:fs";

const SR = 44100;
let seed = 1234567;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const buf = (sec) => new Float32Array(Math.round(sec * SR));
const lp = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return x.map((v) => (y += a * (v - y)));
};
const hp = (x, fc) => {
  const l = lp(x, fc);
  return x.map((v, i) => v - l[i]);
};
// হালকা reverb: কয়েকটি ছোট tap
const reverb = (x, mix = 0.14) => {
  const taps = [[0.017, 0.55], [0.029, 0.4], [0.043, 0.28], [0.061, 0.18]];
  const y = new Float32Array(x.length);
  for (let i = 0; i < x.length; i++) {
    let v = x[i];
    for (const [d, g] of taps) {
      const j = i - Math.round(d * SR);
      if (j >= 0) v += mix * g * x[j];
    }
    y[i] = v;
  }
  return y;
};
const fade = (x, inS, outS) => {
  const a = Math.round(inS * SR), b = Math.round(outS * SR);
  for (let i = 0; i < x.length; i++) {
    if (i < a) x[i] *= i / a;
    const r = x.length - 1 - i;
    if (r < b) x[i] *= r / b;
  }
  return x;
};
const normalize = (x, peak = 0.9) => {
  let m = 0;
  for (const v of x) m = Math.max(m, Math.abs(v));
  const g = m > 0 ? peak / m : 1;
  return x.map((v) => v * g);
};

const pop = () => {
  const x = buf(0.22);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 190 + 430 * Math.exp(-t * 34);
    ph += (2 * Math.PI * f) / SR;
    const env = Math.min(1, t / 0.004) * Math.exp(-t * 20);
    x[i] = (Math.sin(ph) + 0.18 * Math.sin(2 * ph)) * env;
  }
  return fade(reverb(lp(x, 3600), 0.1), 0, 0.03);
};

const click = () => {
  const x = buf(0.12);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const env = Math.min(1, t / 0.001) * Math.exp(-t * 170);
    x[i] = rnd() * env;
  }
  const h = hp(x, 2200);
  for (let i = 0; i < h.length; i++) {
    const t = i / SR;
    h[i] += 0.5 * Math.sin(2 * Math.PI * 1500 * t) * Math.exp(-t * 220);
  }
  return fade(reverb(lp(h, 7500), 0.08), 0, 0.02);
};

const whoosh = () => {
  const dur = 0.75;
  const n = Math.round(dur * SR);
  const y = new Float32Array(n);
  // Chamberlin state-variable band-pass, sweep 350→2600Hz
  let low = 0, band = 0;
  const q = 0.55;
  for (let i = 0; i < n; i++) {
    const t = i / n;
    const fc = 350 * Math.pow(2600 / 350, t * t * (3 - 2 * t));
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    const input = rnd();
    low += f * band;
    const high = input - low - q * band;
    band += f * high;
    const env = Math.pow(Math.sin(Math.PI * Math.pow(t, 0.8)), 2);
    y[i] = band * env;
  }
  return fade(reverb(lp(y, 5200), 0.1), 0.03, 0.12);
};

const chime = () => {
  const x = buf(0.5);
  const parts = [[1046.5, 1, 7], [1568, 0.45, 9], [2093, 0.2, 12], [2637, 0.1, 15]];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let v = 0;
    for (const [f, g, d] of parts) v += g * Math.sin(2 * Math.PI * f * t) * Math.exp(-t * d);
    x[i] = v * Math.min(1, t / 0.004);
  }
  return fade(reverb(lp(x, 6500), 0.14), 0, 0.12);
};

const thud = () => {
  const x = buf(0.3);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 48 + 62 * Math.exp(-t * 26);
    ph += (2 * Math.PI * f) / SR;
    const env = Math.min(1, t / 0.006) * Math.exp(-t * 15);
    x[i] = (Math.sin(ph) + 0.25 * Math.sin(2 * ph)) * env;
  }
  return fade(lp(x, 420), 0, 0.05);
};

const writeWav = (name, data) => {
  const n = data.length;
  const out = Buffer.alloc(44 + n * 2);
  out.write("RIFF", 0); out.writeUInt32LE(36 + n * 2, 4); out.write("WAVE", 8);
  out.write("fmt ", 12); out.writeUInt32LE(16, 16); out.writeUInt16LE(1, 20); out.writeUInt16LE(1, 22);
  out.writeUInt32LE(SR, 24); out.writeUInt32LE(SR * 2, 28); out.writeUInt16LE(2, 32); out.writeUInt16LE(16, 34);
  out.write("data", 36); out.writeUInt32LE(n * 2, 40);
  let clipped = 0, peak = 0, sum = 0;
  for (let i = 0; i < n; i++) {
    const v = Math.max(-1, Math.min(1, data[i]));
    if (Math.abs(data[i]) > 1) clipped++;
    peak = Math.max(peak, Math.abs(v));
    sum += v * v;
    out.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  fs.mkdirSync("public/sfx", { recursive: true });
  fs.writeFileSync(`public/sfx/${name}.wav`, out);
  console.log(
    `${name.padEnd(7)} ${(n / SR).toFixed(2)}s  peak ${peak.toFixed(2)}  rms ${Math.sqrt(sum / n).toFixed(3)}  clipped ${clipped}`,
  );
};

// সবার peak ≈ 0.9; মোট ভলিউম Sfx.tsx-এ ০.২–০.৩ করা হয়
const target = { pop: 0.9, click: 0.85, whoosh: 0.9, chime: 0.88, thud: 0.9 };
const gens = { pop, click, whoosh, chime, thud };
for (const [k, g] of Object.entries(gens)) writeWav(k, normalize(g(), target[k]));
